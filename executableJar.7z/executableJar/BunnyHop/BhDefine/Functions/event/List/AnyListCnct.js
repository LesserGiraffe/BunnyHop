(function() {
    
    let name = bhReplacedNewNode.getSymbolName();
    return 'NumList'   === name ||
    	   'StrList'   === name ||
    	   'BoolList'  === name ||
    	   'ColorList' === name ||
    	   'SoundList' === name;
})();

