(function() {
	return true;
})();