#!/bin/bash
cd `dirname $0`
java -jar BunnyHop.jar
