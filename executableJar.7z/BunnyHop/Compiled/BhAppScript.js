	let _jThread = Java.type('java.lang.Thread');
	let _jExecutors = Java.type('java.util.concurrent.Executors');
	let _jLock = Java.type('java.util.concurrent.locks.ReentrantLock');
	let _eventHandlers = {};
	let _executor = _jExecutors.newFixedThreadPool(16);

	function _genCallObj() {
		return {_outArgs:[]};
	}
	
	function _copyArgs(dest, args, beginIdx) {
		dest.length = 0;
		for (let i = beginIdx; i < args.length; ++i)
			dest.push(args[i]);
	}

	function _genLockObj() {
		return new _jLock();
	}
	
	function _tryLock(lockObj) {
		return lockObj.tryLock();
	}

	function _unlock(lockObj) {
		lockObj.unlock();
	}

	//イベント名とイベントハンドラを登録
	function _addEvent(eventHandler, event) {

		if (_eventHandlers[event] === void 0)
			_eventHandlers[event] = [];

		_eventHandlers[event].push(eventHandler);
	}

	//イベントに応じたイベントハンドラを呼ぶ
	function _fireEvent(event) {
		if (_eventHandlers[event] !== void 0) {
			_eventHandlers[event].forEach(
				function(handler) {
					try {_executor['submit(java.util.concurrent.Callable)'](function() {handler();});}
					catch(e) {}
				}
			);
		}
	}

	function _boolToStr(boolVal) {
		return (boolVal === true) ? '真' : '偽';
	}
	
	function _strToNum(strVal) {
		const num = Number(strVal);
		if (isFinite(num))
			return num;
		return 0;
	}

	function _randomInt(min, max) {
		min = Math.ceil(min);
		max = Math.ceil(max);
		return Math.floor(Math.random() * (max - min + 1)) + min;
	}

	function _println(str) {
		inout.println(str);
	}

	function _sleep(sec) {

		if (sec <= 0)
			return;
		try {
			_jThread.sleep(Math.round(sec * 1000));
		}
		catch (e) {}
	}

	function _scan(str) {
		inout.println(str);
		let input = inout.scan();
		return (input === null) ? "" : input;
	}

	function _aryPush(ary, val) {
		ary.push(val);
	}

	function _aryPop(ary) {
		ary.pop();
	}

	function _aryInsert(ary, idx, val) {
		idx = Math.floor(idx);
		if (0 <= idx && idx <= ary.length)
			ary.splice(idx, 0, val);
	}

	function _aryRemove(ary, idx) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			ary.splice(idx, 1);
	}

	function _aryClear(ary) {
		ary.length = 0;
	}

	function _aryAddAll(aryA, aryB) {
		Array.prototype.push.apply(aryA, aryB);
	}

	function _aryGet(ary, idx, dflt) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			return ary[idx];
		return dflt;
	}

	function _arySet(ary, idx, val) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			ary[idx] = val;
	}


	const _MAX_SPEED = 10;
	const _MIN_SPEED = 1;

	function _moveForward(speed, time) {
		speed = Math.min(Math.max(_MIN_SPEED, speed), _MAX_SPEED);
		_println("速度 " + speed + " で " + time + " 秒間「前進」した")
	}

	function _moveBackward(speed, time) {
		speed = Math.min(Math.max(_MIN_SPEED, speed), _MAX_SPEED);
		_println("速度 " + speed + " で " + time + " 秒間「後退」した")
	}

	function _turnRight(speed, time) {
		speed = Math.min(Math.max(_MIN_SPEED, speed), _MAX_SPEED);
		_println("速度 " + speed + " で " + time + " 秒間「右旋回」した")
	}

	function _turnLeft(speed, time) {
		speed = Math.min(Math.max(_MIN_SPEED, speed), _MAX_SPEED);
		_println("速度 " + speed + " で " + time + " 秒間「左旋回」した")
	}
	
	function _measureDistance() {
	
		let dist = _scan('距離を入力してください (標準入力に半角で)');
		dist = Number(dist);
		if (!isFinite(dist))
			dist = 0;
		
		_println("距離 = " + dist);
		return dist;
	}
	
	let _v13a = []; /*平均を求めたいリスト*/
	let _v13f = 0; /*リストの合計*/
	let _v144 = 0; /*リストの平均*/
	function _f8d(
		_v122, /*リスト*/
		_v12b, /*合計*/
		_v130 /*平均*/) {
		(function (){/*リストの平均と合計を求める*/
			let _callObj;
			_v12b = (0);
			{
				let _vf2 = 0; /*カウンター*/
				_vf2 = (0);
				const _vaf = _v122.length;
				const __vac = Math.floor(_vaf);
				for (let _vac = 0; _vac<__vac; ++_vac) {
					const _vc3 = _aryGet(_v122,_vf2,0);
					_v12b += _vc3;
					_vf2 += (1);
				}
			}
			const _v10a = _v122.length;
			const _v102 = _v12b / _v10a;
			const __v102 = (isFinite(_v102)) ? _v102 : _v12b;
			_v130 = __v102;
		})();
		_copyArgs(this._outArgs,arguments,1);
	}

	let _lockObj_bhMain = (_genLockObj());
	function _bhMain(){
		try {
			if (_tryLock(_lockObj_bhMain)) {
				(function (){
					_aryPush(_v13a,(10));
					_aryPush(_v13a,(50));
					_aryPush(_v13a,(60));
					_callObj = _genCallObj();
					_f8d.call(_callObj,_v13a,_v13f,_v144);
					_v13f = _callObj._outArgs[0];
					_v144 = _callObj._outArgs[1];
					const _v58 = String(_v13f);
					const _v53 = ('合計  ') + _v58;
					_println(_v53);
					const _v6c = String(_v144);
					const _v67 = ('平均  ') + _v6c;
					_println(_v67);
				})();
			}
		}
		catch (e) {}
		finally {_unlock(_lockObj_bhMain);}
	}
	_addEvent(_bhMain,'PROGRAM_START');

