(function(){

	const outArgs = [];

	function _copyArgs(dest, args, beginIdx) {
		dest.length = 0;
		for (let i = beginIdx; i < args.length; ++i)
			dest.push(args[i]);
	}

	function _boolToStr(boolVal) {
		return (boolVal === true) ? '真' : '偽';
	}
	
	function _strToNum(strVal) {
		const num = Number(strVal);
		if (isFinite(num))
			return num;
		return 0;
	}

	function _randomInt(min, max) {
		min = Math.ceil(min);
		max = Math.ceil(max);
		return Math.floor(Math.random() * (max - min + 1)) + min;
	}

	function _println(str) {
		inout.println(str);
	}

	function _sleep(sec) {
		try {
			java.lang.Thread.sleep(Math.round(sec * 1000));
		}
		catch (e) {}
	}

	function _scan(str) {
		inout.println(str);
		let input = inout.scan();
		return (input === null) ? "" : input;
	}

	function _aryPush(ary, val) {
		ary.push(val);
	}

	function _aryPop(ary) {
		ary.pop();
	}

	function _aryInsert(ary, idx, val) {
		idx = Math.floor(idx);
		if (0 <= idx && idx <= ary.length)
			ary.splice(idx, 0, val);
	}

	function _aryRemove(ary, idx) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			ary.splice(idx, 1);
	}

	function _aryClear(ary) {
		ary.length = 0;
	}

	function _aryAddAll(aryA, aryB) {
		Array.prototype.push.apply(aryA, aryB);
	}

	function _aryGet(ary, idx, dflt) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			return ary[idx];
		return dflt;
	}

	function _arySet(ary, idx, val) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			ary[idx] = val;
	}


	const _MAX_SPEED = 10;
	const _MIN_SPEED = 1;

	function _moveForward(speed, time) {
		speed = Math.min(Math.max(_MIN_SPEED, speed), _MAX_SPEED);
		_println("速度 " + speed + " で " + time + " 秒間「前進」した")
	}

	function _moveBackward(speed, time) {
		speed = Math.min(Math.max(_MIN_SPEED, speed), _MAX_SPEED);
		_println("速度 " + speed + " で " + time + " 秒間「後退」した")
	}

	function _turnRight(speed, time) {
		speed = Math.min(Math.max(_MIN_SPEED, speed), _MAX_SPEED);
		_println("速度 " + speed + " で " + time + " 秒間「右旋回」した")
	}

	function _turnLeft(speed, time) {
		speed = Math.min(Math.max(_MIN_SPEED, speed), _MAX_SPEED);
		_println("速度 " + speed + " で " + time + " 秒間「左旋回」した")
	}
	
	function _measureDistance() {
	
		let dist = _scan('距離を入力してください (標準入力に半角で)');
		dist = Number(dist);
		if (!isFinite(dist))
			dist = 0;
		
		_println("距離 = " + dist);
		return dist;
	}
	
	let _v13a = []; /*数値リスト*/
	let _v13f = 0; /*合計値*/
	let _v144 = 0; /*平均値*/
	function _f8d(
		_v122, /*入力リスト*/
		_v12b, /*合計*/
		_v130 /*平均*/) {
		(function(){/*リストの平均と合計を求める*/
			_v12b = (0);
			{
				let _vf2 = 0; /*カウンター*/
				_vf2 = (0);
				const _vaf = _v122.length;
				const __vac = _vaf;
				for (let _vac = 0; _vac<__vac; ++_vac) {
					const _vc3 = _aryGet(_v122,_vf2,0);
					_v12b += _vc3;
					_vf2 += (1);
				}
			}
			const _v10a = _v122.length;
			const _v102 = _v12b / _v10a;
			const __v102 = (isFinite(_v102)) ? _v102 : _v12b;
			_v130 = __v102;
		})();
		_copyArgs(outArgs,arguments,1);
	}

	_aryPush(_v13a,(10));
	_aryPush(_v13a,(50));
	_aryPush(_v13a,(60));
	_f8d(_v13a,_v13f,_v144);
	_v13f = outArgs[0];
	_v144 = outArgs[1];
	const _v58 = String(_v13f);
	const _v53 = ('合計は ') + _v58;
	_println(_v53);
	const _v6c = String(_v144);
	const _v67 = ('平均は ') + _v6c;
	_println(_v67);
})();