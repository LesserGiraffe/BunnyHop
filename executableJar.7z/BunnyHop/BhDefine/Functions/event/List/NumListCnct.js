(function() {
	return 'NumList' === bhReplacedNewNode.getSymbolName();
})();