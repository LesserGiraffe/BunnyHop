(function() {
	return 'BoolList' === bhReplacedNewNode.getSymbolName();
})();