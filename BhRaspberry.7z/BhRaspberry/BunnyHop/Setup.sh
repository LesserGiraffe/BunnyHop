#!/bin/bash
cd `dirname $0`
chmod -R 777 .
