(function(){

	function boolToStr(boolVal) {
		return (boolVal === true) ? '真' : '偽';
	}

	function _fdb37a06(
		_v4cae76e2) {
		
		
		
		while (true) {
			let _v224f9d79 = _v4cae76e2 - 4;
			
			if (!isFinite(_v224f9d79)) {
				_v224f9d79 = _v4cae76e2;
			}
			let _v6ce995b2 = _v224f9d79 < 10;
			if (!_v6ce995b2) {
				break;
			}
			
			_v38f42074 = String(_v4cae76e2);
			print(_v38f42074);
			let _v44fc6394 = _v4cae76e2 + 1;
			if (!isFinite(_v44fc6394))
				_v44fc6394 = _v4cae76e2;
			_v4cae76e2 = _v44fc6394;
			
		}
	}

	_fdb37a06(0);
})();
