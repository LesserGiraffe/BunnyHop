(function(){

	function _boolToStr(boolVal) {
		return (boolVal === true) ? '真' : '偽';
	}

	function _println(str) {
		inout.println(str);
	}

	function _scan(str) {
		inout.println(str);
		let input = inout.scan();
		return (input === null) ? "" : input;
	}

	function _aryPush(ary, val) {
		ary.push(val);
	}

	function _aryPop(ary) {
		ary.pop();
	}

	function _aryInsert(ary, idx, val) {
		idx = Math.floor(idx);
		if (0 <= idx && idx <= ary.length)
			ary.splice(idx, 0, val);
	}

	function _aryRemove(ary, idx) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			ary.splice(idx, 1);
	}

	function _aryClear(ary) {
		ary.length = 0;
	}

	function _aryAddAll(aryA, aryB) {
		Array.prototype.push.apply(aryA, aryB);
	}

	function _aryGet(ary, idx, dflt) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			return ary[idx];
		return dflt;
	}

	function _arySet(ary, idx, val) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			ary[idx] = val;
	}

	let _v47 = []; /*リストA*/
	let _v4c = 0; /*i*/
	function _f54(
		_vb8 /*パラメータリストX*/) {
		_v4c = 0;
		while (true) {
			const _v70 = _vb8.length;
			const _v68 = _v4c < _v70;
			if (!_v68) {
				break;
			}
			const _v81 = _aryGet(_vb8,_v4c,'');
			_println(_v81);
			const _v9c = _v4c + 1;
			const __v9c = (isFinite(_v9c)) ? _v9c : _v4c;
			_v4c = __v9c;
		}
	}

	_aryPush(_v47,'textA');
	_aryPush(_v47,'textB');
	_aryPush(_v47,'textC');
	_f54(_v47);
})();