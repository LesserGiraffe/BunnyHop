
	function boolToStr(boolVal) {
		return (boolVal === true) ? '真' : '偽';
	}

