(function(){

	function _boolToStr(boolVal) {
		return (boolVal === true) ? '真' : '偽';
	}
	
	function _strToNum(strVal) {
		const num = Number(strVal);
		if (isFinite(num))
			return num;
		return 0;
	}

	function _randomInt(min, max) {
		min = Math.ceil(min);
		max = Math.ceil(max);
		return Math.floor(Math.random() * (max - min + 1)) + min;
	}

	function _println(str) {
		inout.println(str);
	}

	function _sleep(sec) {
		try {
			java.lang.Thread.sleep(Math.round(sec * 1000));
		}
		catch (e) {}
	}

	function _scan(str) {
		inout.println(str);
		let input = inout.scan();
		return (input === null) ? "" : input;
	}

	function _aryPush(ary, val) {
		ary.push(val);
	}

	function _aryPop(ary) {
		ary.pop();
	}

	function _aryInsert(ary, idx, val) {
		idx = Math.floor(idx);
		if (0 <= idx && idx <= ary.length)
			ary.splice(idx, 0, val);
	}

	function _aryRemove(ary, idx) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			ary.splice(idx, 1);
	}

	function _aryClear(ary) {
		ary.length = 0;
	}

	function _aryAddAll(aryA, aryB) {
		Array.prototype.push.apply(aryA, aryB);
	}

	function _aryGet(ary, idx, dflt) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			return ary[idx];
		return dflt;
	}

	function _arySet(ary, idx, val) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			ary[idx] = val;
	}


	const _MOVE_CMD = {
		MOVE_FORWARD : '1',
		MOVE_BACKWARD : '2',
		TURN_RIGHT : '3',
		TURN_LEFT : '4'
	};
	
	function _moveAny(speed, time, cmd) {
	
		const _MAX_SPEED = 10;
		const _MIN_SPEED = 1;
		speed = (speed - _MIN_SPEED) / (_MAX_SPEED - _MIN_SPEED);
		speed = Math.min(Math.max(0.0, speed), 1.0);
		time *= 1000;
		time = Math.floor(time);
		let moveCmd = execPath + '/actions' + '/bhMove';
		const procBuilder = new java.lang.ProcessBuilder([moveCmd, cmd, String(time), String(speed)]);
		try {
			const process =  procBuilder.start();
			process.waitFor();
			process.getErrorStream().close();
			process.getInputStream().close();
			process.getOutputStream().close();
		}
		catch (e) {
			_println('ERR: _move ' + cmd + ' ' + e);
		}
	}

	function _moveForward(speed, time) {
		_moveAny(speed, time, _MOVE_CMD.MOVE_FORWARD);
	}

	function _moveBackward(speed, time) {
		_moveAny(speed, time, _MOVE_CMD.MOVE_BACKWARD);
	}

	function _turnRight(speed, time) {
		_moveAny(speed, time, _MOVE_CMD.TURN_RIGHT);
	}

	function _turnLeft(speed, time) {
		_moveAny(speed, time, _MOVE_CMD.TURN_LEFT);
	}

	function readStream(stream) {
		let readByte = [];
		while(true) {
			const rb = stream.read();
			if (rb === -1)
				break;
			readByte.push(rb);
		}
		readByte = Java.to(readByte, "byte[]");
		const string = Java.type("java.lang.String");
		return new string(readByte);
	}

	function _measureDistance() {
	
		let spiCmd = execPath + '/actions' + '/bhSpiRead';
		const procBuilder = new java.lang.ProcessBuilder([spiCmd, '5', '3']);
		let distance;
		try {
			const process =  procBuilder.start();
			process.waitFor();
			distance = readStream(process.getInputStream());
			process.getErrorStream().close();
			process.getInputStream().close();
			process.getOutputStream().close();
		}
		catch (e) {
			_println('ERR: _measureDistance ' + e);
		}
		distance = Number(distance);
		if (!isFinite(distance))
			return 0;
		if (distance >= 384)
			distance = 49840 * Math.pow(distance, -1.142);
		else
			distance = 467132 * Math.pow(distance, -1.522);
		return distance;
	}
	const _v9 = _scan(('入力待ちです'));
	const _v6 = _strToNum(_v9);
	_moveBackward((2),_v6);
})();