#!/bin/bash
cd `dirname $0`
pkill -f BhProgramExecEnvironment.jar
pkill -f bhMove
./actions/bhMove 0
java -jar -Djava.rmi.server.hostname=$1 ./BhProgramExecEnvironment.jar false
