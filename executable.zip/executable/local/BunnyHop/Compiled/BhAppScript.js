(function(){

	function _boolToStr(boolVal) {
		return (boolVal === true) ? '真' : '偽';
	}
	
	function _strToNum(strVal) {
		const num = Number(strVal);
		if (isFinite(num))
			return num;
		return 0;
	}

	function _randomInt(min, max) {
		min = Math.ceil(min);
		max = Math.ceil(max);
		return Math.floor(Math.random() * (max - min + 1)) + min;
	}

	function _println(str) {
		inout.println(str);
	}

	function _sleep(sec) {
		try {
			java.lang.Thread.sleep(Math.round(sec * 1000));
		}
		catch (e) {}
	}

	function _scan(str) {
		inout.println(str);
		let input = inout.scan();
		return (input === null) ? "" : input;
	}

	function _aryPush(ary, val) {
		ary.push(val);
	}

	function _aryPop(ary) {
		ary.pop();
	}

	function _aryInsert(ary, idx, val) {
		idx = Math.floor(idx);
		if (0 <= idx && idx <= ary.length)
			ary.splice(idx, 0, val);
	}

	function _aryRemove(ary, idx) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			ary.splice(idx, 1);
	}

	function _aryClear(ary) {
		ary.length = 0;
	}

	function _aryAddAll(aryA, aryB) {
		Array.prototype.push.apply(aryA, aryB);
	}

	function _aryGet(ary, idx, dflt) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			return ary[idx];
		return dflt;
	}

	function _arySet(ary, idx, val) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			ary[idx] = val;
	}


	const _MAX_SPEED = 10;
	const _MIN_SPEED = 1;

	function _moveForward(speed, time) {
		speed = Math.min(Math.max(_MIN_SPEED, speed), _MAX_SPEED);
		_println("速度 " + speed + " で " + time + " 秒間「前進」した")
	}

	function _moveBackward(speed, time) {
		speed = Math.min(Math.max(_MIN_SPEED, speed), _MAX_SPEED);
		_println("速度 " + speed + " で " + time + " 秒間「後退」した")
	}

	function _turnRight(speed, time) {
		speed = Math.min(Math.max(_MIN_SPEED, speed), _MAX_SPEED);
		_println("速度 " + speed + " で " + time + " 秒間「右旋回」した")
	}

	function _turnLeft(speed, time) {
		speed = Math.min(Math.max(_MIN_SPEED, speed), _MAX_SPEED);
		_println("速度 " + speed + " で " + time + " 秒間「左旋回」した")
	}
	
	function _measureDistance() {
	
		let dist = _scan('距離を入力してください (半角)');
		dist = Number(dist);
		if (!isFinite(dist))
			dist = 0;
		
		_println("距離 = " + dist);
		return dist;
	}
	
	let _ve8 = []; /*リストA*/
	let _ved = 0; /*平均*/
	function _f54(
		_ve0 /*平均を求めるリスト*/) {
		{
			let _vd1 = 0; /*カウンター*/
			let _vd6 = 0; /*合計*/
			_vd1 = (0);
			const _v6c = _ve0.length;
			const __v69 = _v6c;
			for (let _v69 = 0; _v69<__v69; ++_v69) {
				const _v80 = _aryGet(_ve0,_vd1,0);
				_vd6 += _v80;
				_vd1 += (1);
			}
			const _vb7 = _ve0.length;
			const _vaf = _vd6 / _vb7;
			const __vaf = (isFinite(_vaf)) ? _vaf : _vd6;
			_ved = __vaf;
		}
	}

	_aryPush(_ve8,(3));
	_aryPush(_ve8,(5));
	_aryPush(_ve8,(10));
	_f54(_ve8);
	const _v3d = String(_ved);
	_println(_v3d);
})();