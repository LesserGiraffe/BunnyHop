(function(){

	function _boolToStr(boolVal) {
		return (boolVal === true) ? '真' : '偽';
	}
	
	function _strToNum(strVal) {
		const num = Number(strVal);
		if (isFinite(num))
			return num;
		return 0;
	}

	function _randomInt(min, max) {
		min = Math.ceil(min);
		max = Math.ceil(max);
		return Math.floor(Math.random() * (max - min + 1)) + min;
	}

	function _println(str) {
		inout.println(str);
	}

	function _sleep(sec) {
		try {
			java.lang.Thread.sleep(Math.round(sec * 1000));
		}
		catch (e) {}
	}

	function _scan(str) {
		inout.println(str);
		let input = inout.scan();
		return (input === null) ? "" : input;
	}

	function _aryPush(ary, val) {
		ary.push(val);
	}

	function _aryPop(ary) {
		ary.pop();
	}

	function _aryInsert(ary, idx, val) {
		idx = Math.floor(idx);
		if (0 <= idx && idx <= ary.length)
			ary.splice(idx, 0, val);
	}

	function _aryRemove(ary, idx) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			ary.splice(idx, 1);
	}

	function _aryClear(ary) {
		ary.length = 0;
	}

	function _aryAddAll(aryA, aryB) {
		Array.prototype.push.apply(aryA, aryB);
	}

	function _aryGet(ary, idx, dflt) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			return ary[idx];
		return dflt;
	}

	function _arySet(ary, idx, val) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			ary[idx] = val;
	}


	const _MOVE_CMD = {
		MOVE_FORWARD : '1',
		MOVE_BACKWARD : '2',
		TURN_RIGHT : '3',
		TURN_LEFT : '4'
	};
	
	function _getMoveCmd() {
		return execPath + '/actions' + '/bhMove';
	}

	function _moveAny(speed, time, cmd) {
	
		const _MAX_SPEED = 10;
		const _MIN_SPEED = 1;
		speed = (speed - _MIN_SPEED) / (_MAX_SPEED - _MIN_SPEED);
		speed = Math.min(Math.max(0.0, speed), 1.0);
		time *= 1000;
		time = Math.floor(time);
		const procBuilder = new java.lang.ProcessBuilder([_getMoveCmd(), cmd, String(time), String(speed)]);
		try {
			const process =  procBuilder.start();
			process.waitFor();
			process.getErrorStream().close();
			process.getInputStream().close();
			process.getOutputStream().close();
		}
		catch (e) {
			_println('ERR: _move ' + cmd + ' ' + e);
		}
	}

	function _moveForward(speed, time) {
		_moveAny(speed, time, _MOVE_CMD.MOVE_FORWARD);
	}

	function _moveBackward(speed, time) {
		_moveAny(speed, time, _MOVE_CMD.MOVE_BACKWARD);
	}

	function _turnRight(speed, time) {
		_moveAny(speed, time, _MOVE_CMD.TURN_RIGHT);
	}

	function _turnLeft(speed, time) {
		_moveAny(speed, time, _MOVE_CMD.TURN_LEFT);
	}


	let _v10d = 0; /*平均*/
	let _v112 = []; /*リストX*/
	function _f6b(
		_v105 /*リストA*/) {
		{
			let _vf6 = 0; /*カウンター*/
			let _vfb = 0; /*合計*/
			_vfb = (0);
			_vf6 = (0);
			const _v8d = _v105.length;
			const __v8a = _v8d;
			for (let _v8a = 0; _v8a<__v8a; ++_v8a) {
				const _va1 = _aryGet(_v105,_vf6,0);
				_vfb += _va1;
				_vf6 += (1);
			}
			const _vd8 = _v105.length;
			const _vd0 = _vfb / _vd8;
			const __vd0 = (isFinite(_vd0)) ? _vd0 : _vfb;
			_v10d = __vd0;
		}
	}

	_aryPush(_v112,(2));
	_aryPush(_v112,(3));
	_aryPush(_v112,(4));
	_f6b(_v112);
	const _v3d = String(_v10d);
	_println(_v3d);
	_moveForward(_v10d,_v10d);
})();