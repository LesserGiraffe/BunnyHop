(function(){

	function _boolToStr(boolVal) {
		return (boolVal === true) ? '真' : '偽';
	}
	
	function _strToNum(strVal) {
		const num = Number(strVal);
		if (isFinite(num))
			return num;
		return 0;
	}

	function _randomInt(min, max) {
		min = Math.ceil(min);
		max = Math.ceil(max);
		return Math.floor(Math.random() * (max - min + 1)) + min;
	}

	function _println(str) {
		inout.println(str);
	}

	function _scan(str) {
		inout.println(str);
		let input = inout.scan();
		return (input === null) ? "" : input;
	}

	function _aryPush(ary, val) {
		ary.push(val);
	}

	function _aryPop(ary) {
		ary.pop();
	}

	function _aryInsert(ary, idx, val) {
		idx = Math.floor(idx);
		if (0 <= idx && idx <= ary.length)
			ary.splice(idx, 0, val);
	}

	function _aryRemove(ary, idx) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			ary.splice(idx, 1);
	}

	function _aryClear(ary) {
		ary.length = 0;
	}

	function _aryAddAll(aryA, aryB) {
		Array.prototype.push.apply(aryA, aryB);
	}

	function _aryGet(ary, idx, dflt) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			return ary[idx];
		return dflt;
	}

	function _arySet(ary, idx, val) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			ary[idx] = val;
	}

	let _vdb = []; /*数値リスト1*/
	let _ve0 = 0; /*平均*/
	_aryPush(_vdb,10);
	_aryPush(_vdb,20);
	_aryPush(_vdb,60);
	{
		let _va9 = 0; /*カウンター*/
		let _vae = 0; /*合計*/
		_va9 = 0;
		_vae = 0;
		const _v40 = _vdb.length;
		const __v3d = _v40;
		for (let _v3d = 0; _v3d<__v3d; ++_v3d) {
			const _v54 = _aryGet(_vdb,_va9,0);
			_vae += _v54;
			_va9 += 1;
		}
		const _v8b = _vdb.length;
		const _v83 = _vae / _v8b;
		const __v83 = (isFinite(_v83)) ? _v83 : _vae;
		_ve0 = __v83;
	}
	const _vb9 = String(_ve0);
	_println(_vb9);
})();