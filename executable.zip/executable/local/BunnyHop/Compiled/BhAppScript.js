(function(){

	function _boolToStr(boolVal) {
		return (boolVal === true) ? '真' : '偽';
	}
	
	function _strToNum(strVal) {
		const num = Number(strVal);
		if (isFinite(num))
			return num;
		return 0;
	}

	function _randomInt(min, max) {
		min = Math.ceil(min);
		max = Math.ceil(max);
		return Math.floor(Math.random() * (max - min + 1)) + min;
	}

	function _println(str) {
		inout.println(str);
	}

	function _sleep(sec) {
		try {
			java.lang.Thread.sleep(Math.round(sec * 1000));
		}
		catch (e) {}
	}

	function _scan(str) {
		inout.println(str);
		let input = inout.scan();
		return (input === null) ? "" : input;
	}

	function _aryPush(ary, val) {
		ary.push(val);
	}

	function _aryPop(ary) {
		ary.pop();
	}

	function _aryInsert(ary, idx, val) {
		idx = Math.floor(idx);
		if (0 <= idx && idx <= ary.length)
			ary.splice(idx, 0, val);
	}

	function _aryRemove(ary, idx) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			ary.splice(idx, 1);
	}

	function _aryClear(ary) {
		ary.length = 0;
	}

	function _aryAddAll(aryA, aryB) {
		Array.prototype.push.apply(aryA, aryB);
	}

	function _aryGet(ary, idx, dflt) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			return ary[idx];
		return dflt;
	}

	function _arySet(ary, idx, val) {
		idx = Math.floor(idx);
		if (0 <= idx && idx < ary.length)
			ary[idx] = val;
	}


	const _MAX_SPEED = 10;
	const _MIN_SPEED = 1;

	function _moveForward(speed, time) {
		speed = Math.min(Math.max(_MIN_SPEED, speed), _MAX_SPEED);
		_println("速度 " + speed + " で " + time + " 秒間「前進」した")
	}

	function _moveBackward(speed, time) {
		speed = Math.min(Math.max(_MIN_SPEED, speed), _MAX_SPEED);
		_println("速度 " + speed + " で " + time + " 秒間「後退」した")
	}

	function _turnRight(speed, time) {
		speed = Math.min(Math.max(_MIN_SPEED, speed), _MAX_SPEED);
		_println("速度 " + speed + " で " + time + " 秒間「右旋回」した")
	}

	function _turnLeft(speed, time) {
		speed = Math.min(Math.max(_MIN_SPEED, speed), _MAX_SPEED);
		_println("速度 " + speed + " で " + time + " 秒間「左旋回」した")
	}
	
	function _measureDistance() {
	
		let dist = _scan('距離を入力してください (半角)');
		dist = Number(dist);
		if (!isFinite(dist))
			dist = 0;
		
		_println("距離 = " + dist);
		return dist;
	}
	
	let _v54 = []; /*リストA*/
	let _v59 = 0; /*平均*/
	function _f61(
		_ved /*平均を求めるリスト*/) {
		{
			let _vde = 0; /*カウンター*/
			let _ve3 = 0; /*合計*/
			_vde = (0);
			const _v79 = _ved.length;
			const __v76 = _v79;
			for (let _v76 = 0; _v76<__v76; ++_v76) {
				const _v8d = _aryGet(_ved,_vde,0);
				_ve3 += _v8d;
				_vde += (1);
			}
			const _vc4 = _ved.length;
			const _vbc = _ve3 / _vc4;
			const __vbc = (isFinite(_vbc)) ? _vbc : _ve3;
			_v59 = __vbc;
		}
	}

	_aryPush(_v54,(3));
	_aryPush(_v54,(5));
	_aryPush(_v54,(10));
	_f61(_v54);
	const _v3d = String(_v59);
	_println(_v3d);
})();