(function() {
	return bhReplacedNewNode.getSymbolName() === "StrVar";
})();
