(function() {
	return bhReplacedNewNode.getSymbolName() === "BoolVar";
})();
