#!/bin/bash
cd `dirname $0`
java -p . -m net.pflab.bunnyhop/pflab.bunnyhop.root.AppMain
