(function() {
    bhCommon.appendRemovedNode(bhReplacedNewNode, bhThis, bhManuallyReplaced, bhNodeHandler, bhUserOpeCmd);
})();
